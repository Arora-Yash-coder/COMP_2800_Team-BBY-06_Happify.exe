Trying to make an algorithm for 4*4 Tic Tac Toe game.

