module.exports = {
    // url: 'mongodb://localhost:27017/nodejs-demo'
	url:'mongodb+srv://future_curves:13533407585@cluster0-sslsz.mongodb.net/test?retryWrites=true&w=majority'
}