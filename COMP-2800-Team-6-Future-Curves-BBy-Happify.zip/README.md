Team#6 FutureCurves
./app is for configurations
./resources stores the static elements
./tictactoe is a react project
./views contains html and ejs views
./app.js is the server's entrance
./package.json and package-lock.json are the configuration files for nodeJS